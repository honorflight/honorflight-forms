<?php

/*
This file holds the administrative functions of this plugin.  Namely, Salesforce user name, 
password and security token configurations (for storage in database)
*/


?>